package Vue.Page;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class PageReservationSwing extends JFrame {
    private JPanel calendarPanel;
    private JLabel moisLabel;
    private LocalDate currentMonth;

    private final Color COLOR_HAUTE = new Color(102, 204, 102);
    private final Color COLOR_BASSE = new Color(102, 178, 255);
    private final Color COLOR_NOCTURNE = new Color(186, 85, 211);
    private final Color COLOR_SCULPTURE = new Color(255, 165, 0);
    private final Color COLOR_NORMAL = new Color(224, 224, 224);

    public PageReservationSwing() {
        setTitle("📅 Réservation Hop'In");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        currentMonth = LocalDate.now().withDayOfMonth(1);

        JPanel topPanel = new JPanel(new BorderLayout());
        JButton prev = new JButton("⬅");
        JButton next = new JButton("➡");

        moisLabel = new JLabel("", SwingConstants.CENTER);
        moisLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        topPanel.add(prev, BorderLayout.WEST);
        topPanel.add(moisLabel, BorderLayout.CENTER);
        topPanel.add(next, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        calendarPanel = new JPanel(new GridLayout(0, 7, 5, 5));
        calendarPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(calendarPanel, BorderLayout.CENTER);

        JPanel legend = new JPanel(new FlowLayout(FlowLayout.CENTER));
        legend.add(createLegend(COLOR_HAUTE, "Haute saison"));
        legend.add(createLegend(COLOR_BASSE, "Basse saison"));
        legend.add(createLegend(COLOR_NOCTURNE, "Nocturne Halloween"));
        legend.add(createLegend(COLOR_SCULPTURE, "Sculpture citrouille"));
        legend.add(createLegend(COLOR_NORMAL, "Normal"));
        add(legend, BorderLayout.SOUTH);

        prev.addActionListener(e -> {
            currentMonth = currentMonth.minusMonths(1);
            refreshCalendar();
        });

        next.addActionListener(e -> {
            currentMonth = currentMonth.plusMonths(1);
            refreshCalendar();
        });

        refreshCalendar();
        setVisible(true);
    }

    private JPanel createLegend(Color c, String label) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel box = new JLabel("■");
        box.setForeground(c);
        JLabel txt = new JLabel(" " + label);
        p.add(box);
        p.add(txt);
        return p;
    }

    private void refreshCalendar() {
        calendarPanel.removeAll();
        moisLabel.setText(currentMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.FRENCH) + " " + currentMonth.getYear());

        String[] jours = {"Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"};
        for (String j : jours) {
            JLabel lbl = new JLabel(j, SwingConstants.CENTER);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
            calendarPanel.add(lbl);
        }

        LocalDate first = currentMonth;
        int firstDay = first.getDayOfWeek().getValue();
        int total = first.lengthOfMonth();

        for (int i = 1; i < firstDay; i++) calendarPanel.add(new JLabel(""));

        for (int d = 1; d <= total; d++) {
            LocalDate date = currentMonth.withDayOfMonth(d);
            JButton btn = new JButton(String.valueOf(d));
            btn.setOpaque(true);
            btn.setBorderPainted(false);
            btn.setBackground(getColorForDate(date));
            btn.setToolTipText(getSaison(date));

            btn.addActionListener(e -> {
                String[] attractions = {"Laser Game", "Exploration", "Sculpture Citrouille", "Nocturne Halloween"};
                String choix = (String) JOptionPane.showInputDialog(
                        this,
                        "Choisissez une attraction :",
                        "Attraction",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        attractions,
                        attractions[0]
                );

                if (choix != null) {
                    new VueHoraireAttraction(choix, date); // On ouvre la page avec la date et l’attraction choisies
                }
            });


            calendarPanel.add(btn);
        }

        calendarPanel.revalidate();
        calendarPanel.repaint();
    }

    private Color getColorForDate(LocalDate date) {
        return switch (getSaison(date)) {
            case "Haute saison" -> COLOR_HAUTE;
            case "Basse saison" -> COLOR_BASSE;
            case "Nocturne Halloween" -> COLOR_NOCTURNE;
            case "Sculpture citrouille" -> COLOR_SCULPTURE;
            default -> COLOR_NORMAL;
        };
    }

    private String getSaison(LocalDate d) {
        int day = d.getDayOfMonth(), month = d.getMonthValue();

        if (month == 10 && day >= 25) return "Nocturne Halloween";
        if (month == 10 && day >= 19 && day <= 24) return "Sculpture citrouille";
        if (month >= 4 && month <= 8) return "Haute saison";
        if (month == 9 || month == 10) return "Basse saison";
        return "Normal";
    }
}
